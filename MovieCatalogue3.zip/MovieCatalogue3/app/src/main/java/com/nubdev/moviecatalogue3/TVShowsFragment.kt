package com.nubdev.movieandtvshow


import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.nubdev.moviecatalogue3.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.fragment_movies.*
import java.util.*
import kotlin.collections.ArrayList

/**
 * A simple [Fragment] subclass.
 */
class TVShowsFragment : Fragment() {

    private lateinit var adapter: ListTVShowAdapter
    private lateinit var mainViewModel: MainViewModelTVShow

    private val list = ArrayList<Movie>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(    R.layout.fragment_movies, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        mainViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(MainViewModelTVShow::class.java)

        setMovieList()
        showRecyclerList()
    }

    private fun setMovieList() {
        var lang = Locale.getDefault().toLanguageTag()

        mainViewModel.setMovies(lang)
        showLoading(true)

        mainViewModel.getMovies().observe(this, Observer { movieItems ->
            if (movieItems != null) {
                adapter.setData(movieItems)
                showLoading(false)
            }
        })
    }

    override fun onResume() {
        super.onResume()
        setMovieList()
    }

    private fun showRecyclerList() {
        adapter= ListTVShowAdapter()
        adapter.notifyDataSetChanged()
        rv_main.layoutManager = LinearLayoutManager(context)
        rv_main.adapter = adapter
    }

    private fun showLoading(state: Boolean) {
        if (state) {
            progressbar.visibility = View.VISIBLE
        } else {
            progressbar.visibility = View.GONE
        }
    }



}
