package com.nubdev.moviecatalogue3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.nubdev.movieandtvshow.Movie
import kotlinx.android.synthetic.main.activity_movie_detail.*

class MovieDetail : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie_detail)

        val type = intent.getStringExtra("type")
        when (type) {
            "movie" -> displayMovie()
            "tvShow" -> displayTVShow()
        }
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return super.onSupportNavigateUp()
    }

    private fun displayTVShow() {
        val parcelableTVShow = intent.getParcelableExtra<Movie>("parcelable tvShow")
        Glide.with(this)
            .load(parcelableTVShow.poster)
            .into(movie_poster_detail)
        movie_title_detail.text = parcelableTVShow.title
        movie_overview_detail.text = parcelableTVShow.overview
        movie_year_detail.text = parcelableTVShow.year
        supportActionBar?.setTitle("Detail TV Show")
    }

    private fun displayMovie() {
        val parcelableMovie = intent.getParcelableExtra<Movie>("parcelable movie")
        Glide.with(this)
            .load(parcelableMovie.poster)
            .into(movie_poster_detail)
        movie_title_detail.text = parcelableMovie.title
        movie_overview_detail.text = parcelableMovie.overview
        movie_year_detail.text = parcelableMovie.year
        supportActionBar?.setTitle("Detail Movie")
    }
}
